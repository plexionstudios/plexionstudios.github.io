This is an official version of the Metro Dark Theme by Plexion. This is the Pitch Black edition.

You are allowed to use this pack in any youtube videos but you can't re-release this pack without asking me. To leave credit to the pack in the description or any other place only use the official PMC link. Especially don't use profitable links for you such as ad.fly and the likes.

Thanks for co-operating!

You can find me on YouTube and Twitter here:
YT: https://youtube.com/plexion
TW: https://twitter.com/plexionlive